(function () {
  'use strict';

  const VERSION = '1.2.0';
  if (window.__igUnsendVersion === VERSION) return;
  window.__igUnsendVersion = VERSION;

  const GROUP_ROW_SELECTOR = 'div[role="group"][tabindex="-1"], div[role="group"]';

  let isRunning = false;
  let unsendCount = 0;
  let overlay = null;

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function randomDelay(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  function rectOf(el) {
    return el.getBoundingClientRect();
  }

  function textOf(el) {
    return (el?.textContent || '').replace(/\s+/g, ' ').trim();
  }

  function isVisible(el) {
    if (!el?.isConnected) return false;
    const r = rectOf(el);
    const cs = getComputedStyle(el);
    return r.width > 0 && r.height > 0 && cs.display !== 'none' && cs.visibility !== 'hidden' && cs.opacity !== '0';
  }

  function isOnDirectPage() {
    return /instagram\.com\/direct/.test(location.href);
  }

  function isThreadOpen() {
    if (/\/direct\/t\//.test(location.pathname)) return true;
    if (document.querySelector('div[contenteditable="true"][role="textbox"]')) return true;
    if (document.querySelector('[aria-label*="回覆"][role="textbox"]')) return true;
    if (document.querySelector('[aria-label*="Message"][role="textbox"]')) return true;
    return resolveMessagesList().querySelectorAll(GROUP_ROW_SELECTOR).length > 0;
  }

  function looksScrollable(el) {
    if (!isVisible(el)) return false;
    const oy = getComputedStyle(el).overflowY || '';
    return /(auto|scroll|overlay)/i.test(oy) && el.scrollHeight > el.clientHeight + 40;
  }

  function scoreMessagesList(el) {
    if (!el) return -Infinity;
    let score = 0;
    const pagelet = el.getAttribute('data-pagelet') || '';
    if (pagelet === 'IGDMessagesList') score += 100;
    else if (/MessagesList/i.test(pagelet)) score += 70;
    if (looksScrollable(el)) score += 25;
    score += Math.min(el.querySelectorAll('div[role="group"][tabindex="-1"]').length, 30) * 4;
    if (el.querySelector('div[role="presentation"], img, video, canvas, span')) score += 15;
    return score;
  }

  function resolveMessagesList() {
    const candidates = new Set();

    document
      .querySelectorAll('[data-pagelet="IGDMessagesList"], [data-pagelet*="MessagesList"], [data-pagelet*="IGDMessages"]')
      .forEach((el) => candidates.add(el));

    const mainRoot = document.querySelector('main') || document.querySelector('[role="main"]') || document.body;
    candidates.add(mainRoot);

    mainRoot.querySelectorAll('div').forEach((el) => {
      if (looksScrollable(el)) candidates.add(el);
    });

    document.querySelectorAll('div[role="group"][tabindex="-1"]').forEach((row) => {
      let cur = row.parentElement;
      for (let i = 0; i < 7 && cur; i++, cur = cur.parentElement) candidates.add(cur);
    });

    let best = mainRoot;
    let bestScore = -Infinity;
    for (const el of candidates) {
      const score = scoreMessagesList(el);
      if (score > bestScore) {
        bestScore = score;
        best = el;
      }
    }

    return best || document.body;
  }

  function resolveScrollContainer(list) {
    const root = document.scrollingElement || document.documentElement;
    const candidates = [];
    let cur = list;

    while (cur && cur !== document.body) {
      if (cur.scrollHeight > cur.clientHeight + 24) candidates.push(cur);
      cur = cur.parentElement;
    }
    candidates.push(root);

    let best = root;
    let bestScore = -Infinity;

    for (const el of candidates) {
      const oy = getComputedStyle(el).overflowY || '';
      const canScroll = el.scrollHeight > el.clientHeight + 24;
      let score = 0;
      if (canScroll) score += 100;
      if (/(auto|scroll|overlay)/i.test(oy)) score += 40;
      if (el === list) score -= 60;
      score += Math.min(el === root ? window.innerHeight : el.clientHeight || 0, window.innerHeight) / 100;
      if (score > bestScore) {
        bestScore = score;
        best = el;
      }
    }

    return best;
  }

  function buildUnionRect(elements) {
    if (!elements.length) return null;
    let left = Infinity, top = Infinity, right = -Infinity, bottom = -Infinity;
    for (const el of elements) {
      const r = rectOf(el);
      left = Math.min(left, r.left);
      top = Math.min(top, r.top);
      right = Math.max(right, r.right);
      bottom = Math.max(bottom, r.bottom);
    }
    if (!isFinite(left)) return null;
    return { left, top, right, bottom };
  }

  function isStandaloneTextPayloadLeaf(el) {
    if (!isVisible(el)) return false;
    const t = textOf(el);
    if (!t || t.length > 2000) return false;
    if (el.closest('[role="textbox"], [contenteditable="true"]')) return false;
    if (el.querySelector('div[dir="auto"]')) return false;
    const tag = (el.tagName || '').toLowerCase();
    return tag === 'span' || (tag === 'div' && el.getAttribute('dir') === 'auto');
  }

  function getPayloadLeaves(root) {
    const raw = [];
    const add = (el) => { if (el && isVisible(el)) raw.push(el); };

    root.querySelectorAll("span, div[dir='auto'], p").forEach((el) => {
      if (isStandaloneTextPayloadLeaf(el)) add(el);
    });
    root.querySelectorAll('div[role="presentation"], img, video, canvas').forEach((el) => {
      if (isVisible(el)) add(el.closest('[role="button"], div[role="presentation"]') || el);
    });

    const uniq = [];
    const seen = new Set();
    for (const el of raw) {
      if (seen.has(el)) continue;
      seen.add(el);
      uniq.push(el);
    }
    return uniq.filter((item) => !uniq.some((other) => other !== item && other.contains(item)));
  }

  function isSmallProfileImage(img) {
    if (!img || (img.tagName || '').toLowerCase() !== 'img') return false;
    const link = img.closest('a[href]');
    if (!link) return false;
    const href = (link.getAttribute('href') || '').replace(/^\/|\/$/g, '');
    if (!href || href.includes('/')) return false;
    const r = rectOf(img);
    return r.width >= 20 && r.width <= 56 && r.height >= 20 && r.height <= 56;
  }

  function hasIncomingAvatar(row) {
    for (const img of row.querySelectorAll('a[href] img')) {
      if (isSmallProfileImage(img)) return true;
    }
    return false;
  }

  function getRowType(row) {
    if (!row?.isConnected) return null;
    if (hasIncomingAvatar(row)) return 'other';

    const payload = getPayloadLeaves(row);
    if (!payload.length) return null;

    const union = buildUnionRect(payload);
    if (!union) return null;

    const rowRect = rectOf(row);
    const leftGap = Math.max(0, union.left - rowRect.left);
    const rightGap = Math.max(0, rowRect.right - union.right);

    if (rightGap + 24 < leftGap) return 'mine';
    if (leftGap + 24 < rightGap) return 'other';

    const payloadCenterX = (union.left + union.right) / 2;
    const rowCenterX = rowRect.left + rowRect.width / 2;
    return payloadCenterX > rowCenterX ? 'mine' : 'other';
  }

  function isCandidateRow(row) {
    if (!isVisible(row)) return false;
    return getPayloadLeaves(row).length > 0;
  }

  function getCandidateRows(boundary) {
    const rows = new Set();

    boundary.querySelectorAll(GROUP_ROW_SELECTOR).forEach((row) => {
      if (isCandidateRow(row)) rows.add(row);
    });

    for (const leaf of getPayloadLeaves(boundary)) {
      const group = leaf.closest(GROUP_ROW_SELECTOR);
      if (group && boundary.contains(group) && isCandidateRow(group)) {
        rows.add(group);
      }
    }

    const ordered = [...rows].sort((a, b) => {
      const rel = a.compareDocumentPosition(b);
      if (rel & Node.DOCUMENT_POSITION_FOLLOWING) return -1;
      if (rel & Node.DOCUMENT_POSITION_PRECEDING) return 1;
      return 0;
    });

    return ordered.filter((row) => !ordered.some((other) => other !== row && row.contains(other)));
  }

  function dispatchMouseLikeEvent(target, type, point) {
    if (!target?.isConnected) return;
    const init = {
      bubbles: !/enter|leave/i.test(type),
      cancelable: true,
      composed: true,
      clientX: point.x,
      clientY: point.y,
      screenX: point.x,
      screenY: point.y,
      button: 0
    };
    try {
      target.dispatchEvent(new PointerEvent(type.replace('mouse', 'pointer'), { ...init, pointerId: 1, pointerType: 'mouse', isPrimary: true }));
      target.dispatchEvent(new MouseEvent(type, init));
    } catch (_) {}
  }

  function hoverRow(row) {
    if (!row?.isConnected) return;
    const payload = getPayloadLeaves(row);
    const target = payload[0] || row;
    const union = buildUnionRect(payload);
    const point = union
      ? { x: Math.round((union.left + union.right) / 2), y: Math.round((union.top + union.bottom) / 2) }
      : { x: Math.round(rectOf(row).left + rectOf(row).width / 2), y: Math.round(rectOf(row).top + rectOf(row).height / 2) };

    for (const el of [row, target]) {
      dispatchMouseLikeEvent(el, 'pointerover', point);
      dispatchMouseLikeEvent(el, 'pointerenter', point);
      dispatchMouseLikeEvent(el, 'mouseover', point);
      dispatchMouseLikeEvent(el, 'mouseenter', point);
      dispatchMouseLikeEvent(el, 'pointermove', point);
      dispatchMouseLikeEvent(el, 'mousemove', point);
    }

    const propsKey = Object.keys(target).find((k) => k.startsWith('__reactProps$'));
    if (propsKey) {
      const props = target[propsKey];
      const fake = { type: 'pointerenter', target, currentTarget: target, preventDefault() {}, stopPropagation() {} };
      try { props.onPointerEnter?.(fake); } catch (_) {}
      try { props.onMouseEnter?.({ ...fake, type: 'mouseenter' }); } catch (_) {}
    }
  }

  function isStaticThreeVerticalDotsSvg(svg) {
    if ((svg?.tagName || '').toLowerCase() !== 'svg') return false;
    const viewBox = (svg.getAttribute('viewBox') || '').trim();
    if (viewBox && viewBox !== '0 0 24 24') return false;
    const circles = [...svg.querySelectorAll('circle')];
    if (circles.length !== 3) return false;
    const points = circles.map((c) => ({
      cx: Number(c.getAttribute('cx')),
      cy: Number(c.getAttribute('cy')),
      r: Number(c.getAttribute('r'))
    })).sort((a, b) => a.cy - b.cy);
    const expectedY = [6, 12, 18];
    return points.every((p, i) => Math.abs(p.cx - 12) <= 1 && Math.abs(p.cy - expectedY[i]) <= 1 && Math.abs(p.r - 1.5) <= 1);
  }

  function hasThreeDotsIcon(el) {
    if ((el?.tagName || '').toLowerCase() === 'svg' && isStaticThreeVerticalDotsSvg(el)) return true;
    return [...(el?.querySelectorAll('svg') || [])].some(isStaticThreeVerticalDotsSvg);
  }

  function compactPath(d) {
    return String(d || '').replace(/[\s,]+/g, '');
  }

  function isStaticUnsendSvg(svg) {
    if ((svg?.tagName || '').toLowerCase() !== 'svg') return false;
    if ((svg.getAttribute('viewBox') || '').trim() !== '0 0 24 24') return false;
    const paths = [...svg.querySelectorAll('path')].map((p) => compactPath(p.getAttribute('d')));
    if (paths.length < 2) return false;
    const hasCircle = paths.some((d) => d.includes('M12.5C5.659') || d.includes('11.5-11.5'));
    const hasArrow = paths.some((d) => d.includes('M14.51') || d.includes('1.293-1.293'));
    return hasCircle && hasArrow;
  }

  function hasUnsendIcon(el) {
    if ((el?.tagName || '').toLowerCase() === 'svg' && isStaticUnsendSvg(el)) return true;
    return [...(el?.querySelectorAll('svg') || [])].some(isStaticUnsendSvg);
  }

  function isMoreMenuButton(el) {
    if (!el?.isConnected) return false;
    const role = (el.getAttribute('role') || '').toLowerCase();
    const tag = (el.tagName || '').toLowerCase();
    if (role !== 'button' && tag !== 'button') return false;
    if ((el.getAttribute('aria-haspopup') || '').toLowerCase() !== 'menu') return false;
    if (!hasThreeDotsIcon(el)) return false;
    const r = rectOf(el);
    return r.width <= 80 && r.height <= 80;
  }

  function findMoreButtonForRow(row) {
    const roots = [row];
    let cur = row.parentElement;
    for (let i = 0; i < 6 && cur; i++, cur = cur.parentElement) roots.push(cur);

    const candidates = [];
    for (const root of roots) {
      root.querySelectorAll('[role="button"][aria-haspopup="menu"], button[aria-haspopup="menu"]').forEach((btn) => {
        if (isMoreMenuButton(btn)) candidates.push(btn);
      });
    }

    if (!candidates.length) {
      document.querySelectorAll('svg[aria-label]').forEach((svg) => {
        const label = (svg.getAttribute('aria-label') || '').toLowerCase();
        if (label.includes('查看更多') || label.includes('more options') || label.includes('訊息的選項')) {
          const btn = svg.closest('[role="button"]');
          if (btn) candidates.push(btn);
        }
      });
    }

    if (!candidates.length) return null;

    const rowRect = rectOf(row);
    const rowCenterY = rowRect.top + rowRect.height / 2;

    return candidates.sort((a, b) => {
      const ar = rectOf(a);
      const br = rectOf(b);
      const aScore = -Math.abs(ar.top + ar.height / 2 - rowCenterY);
      const bScore = -Math.abs(br.top + br.height / 2 - rowCenterY);
      return bScore - aScore;
    })[0];
  }

  function findUnsendMenuButton() {
    const byIcon = [];
    document.querySelectorAll('svg[viewBox="0 0 24 24"]').forEach((svg) => {
      if (!isStaticUnsendSvg(svg)) return;
      let cur = svg;
      for (let i = 0; i < 10 && cur; i++, cur = cur.parentElement) {
        const role = (cur.getAttribute('role') || '').toLowerCase();
        if (['button', 'menuitem', 'menuitemradio'].includes(role) || (cur.tagName || '').toLowerCase() === 'button') {
          byIcon.push(cur);
          break;
        }
      }
    });
    if (byIcon.length) return byIcon[0];

    const labels = ['收回', '收回訊息', 'unsend', '取消傳送'];
    for (const sel of ['[role="menuitem"]', '[role="menuitemradio"]', 'button', '[role="button"]']) {
      for (const el of document.querySelectorAll(sel)) {
        const text = textOf(el).toLowerCase();
        if (labels.some((l) => text === l || text.includes(l))) return el;
      }
    }
    return null;
  }

  function findConfirmButton() {
    for (const dialog of document.querySelectorAll('[role="dialog"], [aria-modal="true"]')) {
      if (!isVisible(dialog)) continue;
      for (const btn of dialog.querySelectorAll('button')) {
        if (!isVisible(btn)) continue;
        const text = textOf(btn).toLowerCase();
        if (['收回', 'unsend', '確定', 'confirm', 'yes'].some((l) => text === l || text.includes(l))) {
          return btn;
        }
        const cs = getComputedStyle(btn);
        const rgb = cs.color.match(/\d+/g);
        if (rgb && Number(rgb[0]) > 170 && Number(rgb[1]) < 140) return btn;
      }
    }
    return null;
  }

  function setScrollerScrollTop(scroller, top) {
    const root = document.scrollingElement || document.documentElement;
    const next = Math.max(0, Math.round(top));
    if (scroller === root || scroller === document.documentElement || scroller === document.body) {
      window.scrollTo({ top: next, behavior: 'auto' });
    } else {
      scroller.scrollTop = next;
    }
  }

  function getScrollerScrollTop(scroller) {
    const root = document.scrollingElement || document.documentElement;
    if (scroller === root || scroller === document.documentElement || scroller === document.body) {
      return window.scrollY || root.scrollTop || 0;
    }
    return scroller.scrollTop;
  }

  async function scrollUp(scroller) {
    const step = (scroller.clientHeight || window.innerHeight) * 0.85;
    const before = getCandidateRows(resolveMessagesList()).length;
    setScrollerScrollTop(scroller, Math.max(0, getScrollerScrollTop(scroller) - step));
    await sleep(1200);
    const after = getCandidateRows(resolveMessagesList()).length;
    return after !== before;
  }

  function createOverlay() {
    if (overlay) overlay.remove();
    overlay = document.createElement('div');
    overlay.id = 'ig-unsend-overlay';
    overlay.innerHTML = `
      <div class="ig-unsend-card" id="ig-unsend-card">
        <div class="ig-unsend-head">
          <div class="ig-unsend-title">收回中</div>
          <div class="ig-unsend-badge" id="ig-unsend-count">0</div>
        </div>
        <div class="ig-unsend-status" id="ig-unsend-status">準備中…</div>
        <div class="ig-unsend-track"><div class="ig-unsend-track-fill"></div></div>
        <button type="button" class="ig-unsend-stop" id="ig-unsend-stop">停止</button>
      </div>`;
    document.body.appendChild(overlay);
    document.getElementById('ig-unsend-stop')?.addEventListener('click', () => {
      isRunning = false;
      updateOverlay('已停止', unsendCount);
    });
  }

  function updateOverlay(status, count, done) {
    const statusEl = document.getElementById('ig-unsend-status');
    const countEl = document.getElementById('ig-unsend-count');
    const cardEl = document.getElementById('ig-unsend-card');
    if (statusEl) statusEl.textContent = status;
    if (countEl) countEl.textContent = String(count);
    if (cardEl) cardEl.classList.toggle('is-done', Boolean(done));
    chrome.runtime.sendMessage({ action: 'progress', count, status, running: isRunning }).catch(() => {});
  }

  function removeOverlay(delay = 2500) {
    setTimeout(() => { overlay?.remove(); overlay = null; }, delay);
  }

  async function tryUnsendRow(row) {
    row.scrollIntoView({ block: 'center', behavior: 'instant' });
    await sleep(300);
    hoverRow(row);
    await sleep(1000);

    let moreBtn = findMoreButtonForRow(row);
    for (let i = 0; i < 8 && !moreBtn; i++) {
      hoverRow(row);
      await sleep(200);
      moreBtn = findMoreButtonForRow(row);
    }
    if (!moreBtn) return 'no_more';

    moreBtn.click();
    await sleep(900);

    let unsendBtn = null;
    for (let i = 0; i < 20; i++) {
      unsendBtn = findUnsendMenuButton();
      if (unsendBtn) break;
      await sleep(100);
    }
    if (!unsendBtn) {
      document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
      return 'no_unsend';
    }

    unsendBtn.click();
    await sleep(900);

    const confirmBtn = findConfirmButton();
    if (confirmBtn) {
      confirmBtn.click();
      await sleep(800);
    }

    return 'success';
  }

  function getDebugInfo() {
    const list = resolveMessagesList();
    const rows = getCandidateRows(list);
    const mine = rows.filter((r) => getRowType(r) === 'mine');
    const scroller = resolveScrollContainer(list);
    return {
      pathname: location.pathname,
      listPagelet: list.getAttribute?.('data-pagelet') || null,
      totalRows: rows.length,
      mineRows: mine.length,
      scrollerTag: scroller?.tagName,
      scrollerScrollable: scroller ? scroller.scrollHeight > scroller.clientHeight + 24 : false
    };
  }

  async function startUnsending(minDelay, maxDelay) {
    if (isRunning) return { ok: false, error: '收回程序進行中' };

    const list = resolveMessagesList();
    const scroller = resolveScrollContainer(list);
    let rows = getCandidateRows(list);

    if (!rows.length) {
      return {
        ok: false,
        error: '找不到訊息列。請確認聊天室已載入，並重新整理頁面後再試',
        debug: getDebugInfo()
      };
    }

    isRunning = true;
    unsendCount = 0;
    createOverlay();
    updateOverlay('開始掃描你的訊息…', 0);

    let emptyRounds = 0;
    let failRounds = 0;

    while (isRunning) {
      rows = getCandidateRows(list);
      const mineRows = rows.filter((r) => getRowType(r) === 'mine' && !r.dataset.igUnsendDone);

      if (!mineRows.length) {
        const loaded = await scrollUp(scroller);
        emptyRounds++;
        updateOverlay(loaded ? '往上載入更多訊息…' : '掃描中…', unsendCount);
        if (emptyRounds >= 12) {
          updateOverlay('完成了', unsendCount, true);
          break;
        }
        continue;
      }

      emptyRounds = 0;
      const row = mineRows[mineRows.length - 1];
      updateOverlay(`正在收回：${textOf(row).slice(0, 30) || '訊息'}…`, unsendCount);

      const result = await tryUnsendRow(row);

      if (result === 'success') {
        unsendCount++;
        failRounds = 0;
        row.dataset.igUnsendDone = '1';
        updateOverlay('收回成功', unsendCount);
        await sleep(randomDelay(minDelay, maxDelay));
      } else {
        row.dataset.igUnsendDone = '1';
        failRounds++;
        updateOverlay(`略過（${result}）`, unsendCount);
        await sleep(600);
        if (failRounds >= 20 && unsendCount === 0) {
          isRunning = false;
          removeOverlay();
          return {
            ok: false,
            error: '無法觸發收回選單。請手動將滑鼠移到自己的訊息上，確認會出現「⋯」按鈕',
            debug: getDebugInfo()
          };
        }
      }
    }

    isRunning = false;
    removeOverlay();
    return { ok: true, count: unsendCount, debug: getDebugInfo() };
  }

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg.action === 'ping') {
      const list = resolveMessagesList();
      const rows = getCandidateRows(list);
      sendResponse({
        ok: true,
        onDirectPage: isOnDirectPage(),
        threadOpen: isThreadOpen(),
        running: isRunning,
        count: unsendCount,
        debug: {
          ...getDebugInfo(),
          otherRows: rows.length - rows.filter((r) => getRowType(r) === 'mine').length
        }
      });
      return false;
    }

    if (msg.action === 'start') {
      startUnsending(msg.minDelay || 3000, msg.maxDelay || 7000).then(sendResponse);
      return true;
    }

    if (msg.action === 'stop') {
      isRunning = false;
      updateOverlay('已停止', unsendCount);
      removeOverlay();
      sendResponse({ ok: true, count: unsendCount });
      return false;
    }

    return false;
  });
})();
