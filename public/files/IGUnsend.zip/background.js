chrome.runtime.onInstalled.addListener(() => {
  console.log('IG自動訊息收回工具 （Nasir）已安裝');
});
