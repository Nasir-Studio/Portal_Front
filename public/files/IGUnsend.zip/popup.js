const statusEl = document.getElementById('status');
const statusText = document.getElementById('statusText');
const statLine = document.getElementById('statLine');
const startBtn = document.getElementById('startBtn');
const stopBtn = document.getElementById('stopBtn');
const minDelayInput = document.getElementById('minDelay');
const maxDelayInput = document.getElementById('maxDelay');
const progressWrap = document.getElementById('progressWrap');
const progressBar = document.getElementById('progressBar');
const progressText = document.getElementById('progressText');

let currentTabId = null;

function setStatus(type, message, meta) {
  statusEl.className = `status-card status-${type}`;
  statusText.textContent = message;

  if (meta) {
    statLine.textContent = meta;
    statLine.classList.remove('hidden');
  } else {
    statLine.classList.add('hidden');
  }
}

function setWorking(running) {
  startBtn.disabled = running;
  stopBtn.disabled = !running;
  stopBtn.classList.toggle('hidden', !running);
  progressWrap.classList.toggle('hidden', !running);
  progressWrap.classList.toggle('is-active', running);
  progressBar.style.width = running ? '28%' : '0%';
}

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

async function pingContentScript(tabId) {
  try {
    return await chrome.tabs.sendMessage(tabId, { action: 'ping' });
  } catch {
    return null;
  }
}

async function ensureContentScript(tabId) {
  let res = await pingContentScript(tabId);
  if (res) return res;

  await chrome.scripting.executeScript({
    target: { tabId },
    files: ['content.js']
  });

  await new Promise((r) => setTimeout(r, 300));
  return pingContentScript(tabId);
}

function formatStat(debug) {
  if (!debug) return null;
  if (debug.mineRows > 0) {
    return `找到 ${debug.mineRows} 則你的訊息 · 共 ${debug.totalRows} 則`;
  }
  return `此對話共 ${debug.totalRows} 則訊息`;
}

async function init() {
  setWorking(false);
  startBtn.disabled = true;

  const tab = await getActiveTab();
  currentTabId = tab?.id;

  if (!tab?.url?.includes('instagram.com/direct')) {
    setStatus('warn', '請先開啟 Instagram 私訊頁面');
    return;
  }

  const state = await ensureContentScript(currentTabId);
  if (!state?.ok) {
    setStatus('error', '連不上這個分頁', '重新整理 Instagram 後再試一次');
    return;
  }

  if (!state.threadOpen) {
    setStatus('warn', '請先點開一個聊天室', '左側選好對話，右側出現訊息再開始');
    return;
  }

  if (state.running) {
    setStatus('working', '收回進行中', `目前已收回 ${state.count} 則`);
    setWorking(true);
    progressText.textContent = '進度顯示在頁面右上角';
    return;
  }

  const meta = formatStat(state.debug);

  if (state.debug?.mineRows === 0) {
    setStatus('warn', '還沒找到你傳的訊息', meta || '試著往上捲，載入更多歷史');
  } else {
    setStatus('ready', '可以開始了', meta);
  }

  startBtn.disabled = false;
}

startBtn.addEventListener('click', async () => {
  if (!currentTabId) return;

  const minDelay = Math.max(2, Number(minDelayInput.value) || 3) * 1000;
  const maxDelay = Math.max(minDelay / 1000 + 1, Number(maxDelayInput.value) || 7) * 1000;

  if (maxDelay < minDelay) {
    setStatus('error', '最長間隔要大於最短間隔');
    return;
  }

  if (!confirm('確定收回此聊天室中，你傳送的所有訊息？\n\n收回後雙方都看不到，也無法還原。')) {
    return;
  }

  setStatus('working', '正在處理，別關這個分頁');
  setWorking(true);
  progressText.textContent = '自動捲動並逐則收回中…';

  try {
    const response = await chrome.tabs.sendMessage(currentTabId, {
      action: 'start',
      minDelay,
      maxDelay
    });

    if (!response?.ok) {
      const dbg = response?.debug?.mineRows != null
        ? `偵測到 ${response.debug.mineRows} 則你的訊息`
        : null;
      throw new Error(response?.error || '收回失敗');
    }

    progressBar.style.width = '100%';
    progressWrap.classList.remove('is-active');

    if (response.count === 0) {
      setStatus('warn', '結束了，但沒有收回任何訊息', '確認聊天室裡有你傳的訊息（右側氣泡）');
      progressText.textContent = '';
    } else {
      setStatus('ready', `收回了 ${response.count} 則`, '對方那邊也會一併消失');
      progressText.textContent = '完成了';
    }
  } catch (err) {
    setStatus('error', err.message || '出了點問題', null);
    progressText.textContent = '';
  } finally {
    setWorking(false);
  }
});

stopBtn.addEventListener('click', async () => {
  if (!currentTabId) return;
  await chrome.tabs.sendMessage(currentTabId, { action: 'stop' }).catch(() => {});
  setStatus('warn', '正在停止…', '稍等一下就會停下來');
  setWorking(false);
});

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.action !== 'progress' || !msg.running) return;
  progressText.textContent = msg.status;
  if (msg.count > 0) {
    statLine.textContent = `目前已收回 ${msg.count} 則`;
    statLine.classList.remove('hidden');
  }
});

init();
